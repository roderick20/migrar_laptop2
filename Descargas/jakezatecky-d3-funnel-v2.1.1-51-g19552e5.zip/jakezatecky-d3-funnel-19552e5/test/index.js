// Because JSDom does not support SVGs properly this must run in a browser
// https://github.com/jsdom/jsdom/issues/918

import './d3-funnel/Colorizer.js';
import './d3-funnel/D3Funnel.js';
import './d3-funnel/Navigator.js';
import './d3-funnel/Utils.js';
