import D3Funnel from './d3-funnel/D3Funnel.js';

export default D3Funnel;
