declare module 'd3-funnel'
