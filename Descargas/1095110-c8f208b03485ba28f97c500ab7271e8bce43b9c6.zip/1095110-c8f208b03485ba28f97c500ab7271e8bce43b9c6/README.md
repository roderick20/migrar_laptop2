Enlaces con otros ficheros compartidos en los comentarios:

* [Conversor del CSV a otros formatos](https://tableconvert.com/?output=xml&data=https://gist.github.com/brenes/1095110/raw/f8eeb4a7efb257921e6236ef5ce2dbc13c50c059/paises.csv) by @Fechin
* [Versión que incluye regiones como Inglaterra que tienen códigos ISO](https://gist.github.com/ideaalab/7caf20bc8fd6c625163927e2d478e05f) by @ideaalab