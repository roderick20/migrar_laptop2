---
title: Ajax
taxonomy:
    category: docs
---

The `AjaxAdapter` implements support for creating results [from remote data sources using AJAX requests](/data-sources/ajax).

**AMD Modules:**

`select2/data/ajax`
