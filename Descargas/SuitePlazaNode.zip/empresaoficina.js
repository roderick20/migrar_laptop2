const sql = require('mssql');
require('dotenv').config();

const db = {
    server: process.env.SQL_SERVER,
    database: process.env.SQL_DATABASE,
    user: process.env.SQL_UID,
    password: process.env.SQL_PWD,
    options: {
        encrypt: false,
        trustServerCertificate: true,
    }
};



async function Empresaoficina(usuarioid) {
    let pool;
    let result;
    let error = '';
    try {
        pool = await sql.connect(db);
        
        const query = `spPyOPermisoUsuario @usuarioid, 1`
        const request = pool.request();
        request.input('usuarioid', sql.Int, usuarioid );
        result = await request.query(query);
       

        //console.log(result);
    
        console.log(result.recordset[0].personeriaid);
    } catch (err) {
        error = err;
        console.log(err);
    }
    finally {
        if (pool) {
            pool.close();
        }
    }
}

 Empresaoficina(1);//