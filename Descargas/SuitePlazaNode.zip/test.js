console.log("hola");
const sql = require('mssql');
require('dotenv').config();

const db = {
    server: process.env.SQL_SERVER,
    database: process.env.SQL_DATABASE,
    user: process.env.SQL_UID,
    password: process.env.SQL_PWD,
    options: {
        encrypt: false,
        trustServerCertificate: true,
    }
};



async function test(email, password) {
    let pool;
    let result;
    let where = '';
    let error = '';
    try {
        pool = await sql.connect(db);
        

        const query_pass = `select  CONVERT(VARCHAR(32), HashBytes('MD5', @Password), 2) as pwd`
        const request_pass = pool.request();
        request_pass.input('Password', sql.VarChar, password);
        result_pass = await request_pass.query(query_pass);
        pwd = result_pass.recordset[0].pwd;

        const query = `spPyOSelect 'Usuario',  @where`
        const request = pool.request();
        request.input('where', sql.VarChar, `identificacion = '` + email + `' and Clave = '`+pwd +`'` );
        result = await request.query(query);
       

        //console.log('Intercepted Queries:', queryInterceptor.interceptedQueries);
        console.log(result.recordset);
        console.log(result.recordset[0].UsuarioID);
        console.log(result.recordset[0].Nombre);
        console.log(result.recordset[0].Tipo);
    } catch (err) {
        error = err;
        console.log(err);
    }
    finally {
        if (pool) {
            pool.close();
        }
    }
}

 test('admin@email.com', '123456');