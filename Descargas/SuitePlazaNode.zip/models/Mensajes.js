const log = require('../utils/log.js');
const config = require('../utils/config.js');
const sql = require('mssql');

module.exports = function (app) {

    this.list = async function () {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `SELECT 
            Id, UniqueId, Name, Phone,
            CONVERT(NVARCHAR(10), CheckIn, 120) AS CheckIn,
            CONVERT(NVARCHAR(10), CheckOut, 120) AS CheckOut,
            Adults, Children, Notes, ProductId, Room
        FROM dbo.Reservations;;
            `;
            result = await pool.request().query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.TablaEmpresa/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }
    this.listmensaje = async function (Id) { // Agregar Id como parámetro
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `select UniqueId, Name, Email, Subject, Created, Body, IsRead, ReadDate from dbo.Message where Id = @Id;
            `;
            // Declarar y asignar el valor de la variable @Id
            const request = pool.request()
                .input('Id', sql.Int, Id); // Asignar el valor de Id a la variable @Id
            result = await request.query(query);
            console.log('resultados' + result) // Ejecutar la consulta
        } catch (err) {
            error = err;
            log.logError("dbo.TablaEmpresa/list", err);
        } finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }
    this.create = async function (params) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `INSERT INTO dbo.Message (UniqueId, Name, Email, Subject, Created, Body, IsRead, ReadDate)
                            VALUES (NEWID(), @Name, @Email, @Subject, @Created, @Body, @IsRead, @ReadDate);
            `;
            const request = pool.request();
            // request.input('Id', sql.Int, params.Id);
            // request.input('UniqueId', sql.UniqueIdentifier, params.UniqueId);
            request.input('Name', sql.NVarChar(50), params.Name);
            request.input('Email', sql.NVarChar(50), params.Email);
            request.input('Subject', sql.NVarChar, params.Subject);
            request.input('Created', sql.DateTime, params.Created);
            request.input('Body', sql.NText, params.Body);
            request.input('IsRead', sql.Bit, params.IsRead);
            request.input('ReadDate', sql.DateTime, params.ReadDate);
            result = await request.query(query);
            log.logError(result);
        } catch (err) {
            error = err;
            log.logError("dbo.TablaEmpresa/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

}