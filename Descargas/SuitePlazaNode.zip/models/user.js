const log = require('../utils/log.js');
const config = require('../utils/config.js');
const sql = require('mssql');


module.exports = function (app) {

    this.login = async function (params) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `
            SELECT [UniqueId],[Name],[Email],[Password],[LastAccess],[Enabled]
            FROM [dbo].[AuthUser] 
            WHERE [UniqueId] = @Email AND [Clave] = CONVERT(VARCHAR(32), HashBytes('MD5', @Password), 2)`;
            const request = pool.request();
            request.input('Email', sql.VarChar, params.email);
            request.input('Password', sql.VarChar, params.password);
            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("user.js/login", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

    this.create = async function (params, userId) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `
            INSERT INTO [dbo].[AuthUser] ([UniqueId],[Name], [Email], [Password], [LastAccess], [Auth],[Enabled])
                VALUES (NEWID(), @Nombre, @Email, CONVERT(VARCHAR(32), HashBytes('MD5', @Password), 2),GETDATE(),'' ,1)
                `;
            const request = pool.request();
            request.input('Nombre', sql.NVarChar, params.Name);
            request.input('Email', sql.NVarChar, params.Email);
            request.input('Password', sql.NVarChar, params.Password);
            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("user.js/create", err);
        } finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        };
    }


    // this.update = async function (params) {
    //     let pool;
    //     let result;
    //     let error = '';
    //     console.log(params);
    //     try {
    //         pool = await sql.connect(config.db);
    //         const query = `
    //         UPDATE [dbo].[Usuario] SET [Nombre] = @Nombre, [Identificacion] = @Identificacion, [Estado] = @Estado
    //         WHERE [UsuarioID] = @UsuarioID`;
    //         const request = pool.request();
    //         request.input('Nombre', sql.VarChar, params.Nombre);
    //         request.input('Identificacion', sql.VarChar, params.Identificacion);
    //         request.input('Estado', sql.VarChar, params.Estado);
    //         request.input('UsuarioID', sql.Int, params.UsuarioID);

    //         result = await request.query(query);
    //     } catch (err) {
    //         error = err;
    //         log.logError("user.js/update", err);
    //     }
    //     finally {
    //         if (pool) {
    //             pool.close();
    //         }
    //     }
    //     return {
    //         result,
    //         error
    //     }
    // }

    this.update = async function (params) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `
            UPDATE [dbo].[AuthUser]
            SET [Name] = @Nombre
                ,[Email] = @Email                
                ,[Enabled] = @Enabled                
            WHERE [UniqueId] = @UniqueId`;

            const request = pool.request();
            request.input('Nombre', sql.NVarChar, params.Nombre);
            request.input('Email', sql.NVarChar, params.Email);
            request.input('Enabled', sql.Bit, params.Enabled);
            request.input('UniqueId', sql.UniqueIdentifier, params.UniqueId);
            result = await request.query(query);

        } catch (err) {
            error = err;
            log.logError("user.js/update", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

    this.updatePassword = async function (params) {
        let pool, result, error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `
            UPDATE [dbo].[AuthUser]
            SET [Password] = CONVERT(VARCHAR(32), HashBytes('MD5', @Password), 2)               
            WHERE [UniqueId] = @UniqueId`;

            const request = pool.request();
            request.input('Password', sql.VarChar, params.Password);
            request.input('UniqueId', sql.UniqueIdentifier, params.UniqueId);
            result = await request.query(query);

        } catch (err) {
            error = err;
            log.logError("user.js/create", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

    this.remove = async function (params) {
        let pool, result, error = '';
        console.log(params);
        try {
            pool = await sql.connect(config.db);
            const query = `
            DELETE FROM [dbo].[AuthUser]            
            WHERE [UniqueId] = @UniqueId`;

            const request = pool.request();

            request.input('UniqueId', sql.UniqueIdentifier, params.UniqueId);
            result = await request.query(query);

        } catch (err) {
            error = err;
            log.logError("user.js/delete", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

    this.list = async function () {
        let pool, result, error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `SELECT UniqueId, 
                                    Name, 
                                    Email, 
                                    Password, 
                                    LastAccess, 
                                    Auth, 
                                    Enabled, 
                                    CONVERT(varchar, LastAccess, 103) as FormattedLastAccess 
                            FROM [dbo].[AuthUser];
                           `;
            const request = pool.request();

            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("user.js/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

    this.findById = async function (UniqueId) {
        console.log('en el modelo' + UniqueId)
        let pool, result, error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `SELECT UniqueId, 
                                    Name, 
                                    Email, 
                                    Password, 
                                    LastAccess, 
                                    Auth, 
                                    Enabled,
                                    CONVERT(varchar, LastAccess, 103) as FormattedLastAccess 
                           FROM [dbo].[AuthUser] WHERE UniqueId = @UniqueId`;
            const request = pool.request();
            request.input('UniqueId', sql.UniqueIdentifier, UniqueId);
            result = (await request.query(query)).recordset;
        } catch (err) {
            error = err;
            log.logError("user.js/findById", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

    this.select = async function (Id) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `
            SELECT * FROM [dbo].[Usuario] WHERE [UsuarioID] = @Id`;
            const request = pool.request();
            request.input('UsuarioID', sql.Int, Id);
            result = (await request.query(query)).recordset;
        } catch (err) {
            error = err;
            log.logError("user.js/login", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

    this.addAlmacen = async function (params, userId) {
        let pool, result, error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `
            INSERT INTO [dbo].[UsuarioAccesoEmpresa]
           ([UsuarioID]
           ,[EmpresaID]
           ,[OficinaAlmacenID]
           ,[PersoneriaID]
           ,[IDUsuario]
           ,[FechaCreacion]
           ,[FechaModificacion])
     VALUES
           (@UsuarioID
           ,1
           ,@OficinaAlmacenID
           ,@PersoneriaID
           ,1
           ,getdate()
           ,getdate())`;
            const request = pool.request();
            request.input('UsuarioID', sql.Int, params.UserId);
            request.input('OficinaAlmacenID', sql.Decimal(6, 3), params.OficinaAlmacenID);
            request.input('PersoneriaID', sql.Int, 1652); //params.PersoneriaID);

            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("user.js/create", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

    this.deleteAlmacen = async function (UsuarioID, OficinaAlmacenID) {
        let pool, result, error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `
            DELETE FROM [dbo].[UsuarioAccesoEmpresa] WHERE [UsuarioID] = @UsuarioID AND [OficinaAlmacenID] = @OficinaAlmacenID`;
            const request = pool.request();
            request.input('UsuarioID', sql.Int, UsuarioID);
            request.input('OficinaAlmacenID', sql.Decimal(6, 3), OficinaAlmacenID);


            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("user.js/create", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

    return this;

};


// const log = require('../utils/log.js');
// const config = require('../utils/config.js');
// const sql = require('mssql');
// const crypto = require('crypto');

// async function list() {
//     let pool;
//     let result;
//     let error = '';
//     try {
//         pool = await sql.connect(config.db);
//         const query = `
//             SELECT [id]
//             ,[uniqueId]
//             ,[name]
//             ,[email]
//             ,[password]
//             ,[author]
//             ,[created]
//             ,[modified]
//             ,[editor]
//             FROM [dbo].[user];`;
//         result = await pool.request().query(query);
//     } catch (err) {
//         error = err;
//         log.logError("user.js/list", err);
//     }
//     finally {
//         if (pool) {
//             pool.close();
//         }
//     }
//     return {
//         result,
//         error
//     }
// }

// async function listdt(params) {
//     let pool;
//     let result;
//     let resultCount;
//     let error = '';
//     const draw = params.draw;
//     const start = params.start;
//     const length = params.length;
//     const search = params.search.value;

//     try {
//         pool = await sql.connect(config.db);
//         let queryCount = `SELECT COUNT(*) AS count FROM [dbo].[user]`;
//         let query = `
//             SELECT [id]
//             ,[uniqueId]
//             ,[name]
//             ,[email]
//             ,[password]
//             ,[author]
//             ,[created]
//             ,[modified]
//             ,[editor]
//             FROM [dbo].[user]`;

//         const request = pool.request();
//         const requestCount = pool.request();


//         if (search) {
//             query += ` WHERE [name] LIKE @search OR [email] LIKE @search `;
//             //queryCount += ` WHERE [Name] LIKE @search OR [Email] LIKE @search `;
//             request.input('search', sql.VarChar, '%' + search + '%');
//             //requestCount.input('search', sql.VarChar, search);
//         }
//         query += `
//             ORDER BY [name]
//             OFFSET @start ROWS
//             FETCH NEXT @length ROWS ONLY;`;

//         //console.log(query);
//         request.input('start', sql.Int, start * length);//(@pagina - 1) * @tamanoPagina
//         request.input('length', sql.Int, length);
//         result = await request.query(query);
//         //console.log(result);

//         resultCount = await requestCount.query(queryCount);

//     } catch (err) {
//         error = err;
//         console.log(err);
//         log.logError("user.js/list", err);
//     }
//     finally {
//         if (pool) {
//             pool.close();
//         }
//     }


//     //console.log(resultCount);

//     return {
//         draw,
//         recordsTotal: resultCount.recordsets[0][0].count,
//         recordsFiltered: result.recordsets[0].length,
//         data: result.recordsets[0]
//     }
// }

// async function searchEmail(email) {
//     let pool;
//     let result;
//     let error = '';
//     try {
//         pool = await sql.connect(config.db);

//         const query = `
//             SELECT [email]
//             FROM [dbo].[user]
//             WHERE [Email] = @email;
//         `;

//         const request = pool.request();
//         request.input('email', sql.VarChar, email);
//         result = await request.query(query);
//     } catch (err) {
//         error = err;
//         log.logError("user.js/list", err);
//     }
//     finally {
//         if (pool) {
//             pool.close();
//         }
//     }

//     return {
//         result,
//         error
//     }
// }

// async function create(params) {
//     let pool;
//     let result;
//     let error = '';
//     try {
//         pool = await sql.connect(config.db);

//         const query = `
//             INSERT INTO [dbo].[user]
//             ([name], [email], [password], [author])
//             VALUES (@name, @email, @password, @author);
//         `;

//         const hash = crypto.createHash('sha256').update(params.password);
//         const passwordHex = hash.digest('hex');

//         const request = pool.request();
//         request.input('name', sql.VarChar, params.name);
//         request.input('email', sql.VarChar, params.email);
//         request.input('password', sql.VarChar, passwordHex);
//         request.input('author', sql.Int, 1);
//         result = await request.query(query);
//     } catch (err) {
//         error = err;
//         log.logError("user.js/create", err);
//     }
//     finally {
//         if (pool) {
//             pool.close();
//         }
//     }

//     return {
//         result,
//         error
//     }
// }

// async function read(uniqueId) {
//     let pool;
//     let result;
//     let error = '';
//     try {
//         pool = await sql.connect(config.db);

//         const query = `
//         SELECT [id]
//         ,[uniqueId]
//         ,[name]
//         ,[email]
//         ,[password]
//         ,[author]
//         ,[created]
//         ,[modified]
//         ,[editor]
//         FROM [dbo].[user]
//         WHERE uniqueId = @uniqueId;`;

//         const request = pool.request();
//         request.input('uniqueId', sql.UniqueIdentifier, uniqueId);
//         result = await request.query(query);

//     } catch (err) {
//         error = err;
//         log.logError("user.js/read", err);
//     }
//     finally {
//         if (pool) {
//             pool.close();
//         }
//     }


//     return {
//         result,
//         error
//     }
// }

// async function update(params) {
//     let pool;
//     let result;
//     let error = '';
//     try {
//         pool = await sql.connect(config.db);

//         const query = `
//         UPDATE [dbo].[user] SET
//             [name] = @name
//             ,[email] = @email
//             ,[modified] = getdate()
//             ,[editor] = @editor
//         where UniqueId = @uniqueId;`;

//         const request = pool.request();

//         request.input('name', sql.VarChar, params.name);
//         request.input('email', sql.VarChar, params.email);
//         request.input('editor', sql.Int, 1);
//         request.input('uniqueId', sql.UniqueIdentifier, params.uniqueId);
//         result = await request.query(query);
//     } catch (err) {
//         error = err;
//         log.logError("user.js/update", err);
//     }
//     finally {
//         if (pool) {
//             pool.close();
//         }
//     }

//     return {
//         result: result,
//         error: error
//     }
// }

// async function remove(uniqueId) {
//     let pool;
//     let result;
//     let error = '';
//     try {
//         pool = await sql.connect(config.db);

//         const query = `DELETE FROM [dbo].[user] where uniqueId = @uniqueId;`;

//         const request = pool.request();
//         request.input('uniqueId', sql.UniqueIdentifier, uniqueId);
//         result = await request.query(query);
//     } catch (err) {
//         error = err;
//         log.logError("user.js/remove", err);
//     }
//     finally {
//         if (pool) {
//             pool.close();
//         }
//     }

//     return {
//         result: result,
//         error: error
//     }
// }

// module.exports = {
//     list,
//     listdt,
//     create,
//     searchEmail,
//     update,
//     read,
//     remove
// };