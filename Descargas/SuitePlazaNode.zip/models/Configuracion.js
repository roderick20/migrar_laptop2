const log = require('../utils/log.js');
const config = require('../utils/config.js');
const sql = require('mssql');

module.exports = function (app) {

    this.list = async function () {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `select * from dbo.Settings;`;
            result = await pool.request().query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.configuracion/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

    this.listById = async function (UniqueId) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `select * from dbo.Settings WHERE  UniqueId = @UniqueId;`;
            const request = pool.request();
            request.input('UniqueId', sql.NVarChar,UniqueId );
            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.configuracion/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

    this.update = async function (params) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `Update Settings SET
			Value = @Value WHERE UniqueId = @UniqueId; `;
            const request = pool.request();
            request.input('UniqueId', sql.NVarChar, params.UniqueId );
            request.input('Value', sql.NVarChar, params.Value );
            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.configuracion/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

}