const log = require('../utils/log.js');
const config = require('../utils/config.js');
const sql = require('mssql'); 

module.exports = function (app) {

    this.list = async function () {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = ` SELECT
            B.id
            ,B.UniqueId
            ,B.CategoryId
            ,B.Title
            ,B.Slug
            ,B.Imagen
            ,B.Body
            ,B.Summary
            ,B.Tags
            ,B.Auth
            ,B.Price
            ,B.IsPublish
            ,BC.Title as NombreCategoria
            FROM BlogPost AS B JOIN BlogCategory AS BC ON B.CategoryId= BC.Id;
            `;
            result = await pool.request().query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.BLOGPOST/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    },
    this.listservicios = async function () {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = ` select * from dbo.Product where CategoryId=2;
            `;
            result = await pool.request().query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.BLOGPOST/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    },
    this.listhabitaciones = async function () {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = ` select * from dbo.Product where CategoryId=3;
            `;
            result = await pool.request().query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.BLOGPOST/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    },
    this.listproductos = async function () {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = ` select * from dbo.Product;
            `;
            result = await pool.request().query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.BLOGPOST/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    },
    
    this.listposts = async function () {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = ` select * from dbo.blogpost where CategoryId=1;
            `;
            result = await pool.request().query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.BLOGPOST/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    },


    this.create = async function (params) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `
            INSERT INTO Product(
                UniqueId
                ,CategoryId
                ,Title
                ,Slug
                ,Imagen
                ,Body
                ,Summary
                ,Tags
                ,Auth
                ,Price,
                IsPublish)VALUES(
                    NEWID(),
                    @CategoryId,
                    @Title,
                    @Slug,
                    '/uploads/' + @Imagen,
                    @Body,
                    @Summary,
                    @Tags,
                    '1',
                    @Price,
                    @IsPublish);
            `;
            const request = pool.request();
            request.input('Title', sql.VarChar, params.Title);
            //Slug Transformado espacios en guiones para la insercion
            let Titulo = params.Title;
            let i = -1;
            let Espacio = ' '
            let Cambio = '-'
            while ((i = Titulo.indexOf(Espacio, i >= 0 ? i = Cambio.length : 0)) !== -1
            ) { Titulo = Titulo.substring(0, i) + Cambio + Titulo.substring(i + Espacio.length) }
            // console.log(Titulo);
            request.input('Slug', sql.VarChar,Titulo);
            //Slug FIN
            request.input('CategoryId', sql.Int, parseInt(params.CategoryId, 10)); 
            request.input('Imagen', sql.VarChar, params.file);
            request.input('Body', sql.VarChar, params.Body);
            request.input('Summary', sql.VarChar, params.Summary);
            request.input('Tags', sql.VarChar, params.Tags);
            // request.input('Auth', sql.Decimal(8, 2), params.Precio); Por defecto 1
            request.input('Price', sql.Float(18,2), params.Price);
            request.input('IsPublish', sql.Bit, params.IsPublish);

            result = await request.query(query);
            
        } catch (err) {
            error = err;
            log.logError("dbo.BLOGPOST/create", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    },
    this.listBySlug = async function (UniqueId) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `SELECT * FROM dbo.Product WHERE UniqueId = @UniqueId;`;
            const request = pool.request();
            request.input('UniqueId',sql.VarChar,UniqueId);
            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.configuracion/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    },

    //Solucionar Errores
    this.listUpdate = async function (UniqueId, CategoryId, Title, Imagen, Body, Summary, Tags, Price, IsPublish, ImagenOriginal) {
        console.log("********entramos al controlador *************");
        console.log("este es el id enviado xd " + UniqueId);
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const request = pool.request();
            const query = `
                UPDATE Product
                SET
                    CategoryId = @CategoryId,
                    Title = @Title,
                    Imagen = @file,
                    Body = @Body,
                    Summary = @Summary,
                    Tags = @Tags,
                    Price = @Price,
                    IsPublish = @IsPublish
                WHERE
                    UniqueId = @UniqueId;
            `;
            request.input('UniqueId', sql.VarChar, UniqueId);
            request.input('CategoryId', sql.Int, CategoryId);
            request.input('Title', sql.VarChar, Title);
            request.input('file', sql.VarChar(250), Imagen ? Imagen : ImagenOriginal);
            request.input('Body', sql.NText, Body);
            request.input('Summary', sql.NText, Summary);
            request.input('Tags', sql.VarChar, Tags);
            request.input('Price', sql.Numeric, Price);
            request.input('IsPublish', sql.Bit, IsPublish);
            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.BLOGPOST/listUpdate", err);
        } finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }
    

    this.delete = async function (UniqueId2) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `
            DELETE FROM Product WHERE UniqueId = @UniqueId;
            `;
            const request = pool.request();
            request.input('UniqueId',sql.VarChar,UniqueId2);
            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.BLOGPOST/delete", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }
    this.deletereservacion = async function (UniqueId2) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `
            DELETE FROM Reservations WHERE UniqueId = @UniqueId;
            `;
            const request = pool.request();
            request.input('UniqueId',sql.VarChar,UniqueId2);
            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.BLOGPOST/delete", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }
}

