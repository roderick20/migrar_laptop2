const log = require('../utils/log.js');
const config = require('../utils/config.js');
const sql = require('mssql'); 

module.exports = function (app) {

    this.list = async function () {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = ` select * from dbo.Product;
            `;
            result = await pool.request().query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.BLOGPOST/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }
}