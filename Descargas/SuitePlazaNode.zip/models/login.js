const log = require('../utils/log.js');
const config = require('../utils/config.js');
const sql = require('mssql');

login = async function (email,password) {
    let pool;
    let result;
    let error = '';
    try {
        pool = await sql.connect(config.db);
        const query = `
             SELECT [UniqueId],[Name],[Email],[Password],[LastAccess],[Auth],[Enabled]
            FROM [dbo].[AuthUser] 
            WHERE [Email] = @Email AND [Password] = CONVERT(nvarchar(150), HashBytes('MD5', '${password}'), 2);`;
        const request = pool.request();
        request.input('Email', sql.NVarChar, email);
        //request.input('Password', sql.NVarChar, params.password);
        
        // Execute the query and retrieve the result
        result = await request.query(query);
        console.log(request);
        console.log(result);
    } catch (err) {
        error = err;
        log.logError("user.js/login", err);
    }
    finally {
        if (pool) {
            pool.close();
        }
    }
    return {
        result,
        error
    };
}



module.exports = {
    login

};

