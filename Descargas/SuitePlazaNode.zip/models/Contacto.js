const log = require('../utils/log.js');
const config = require('../utils/config.js');
const sql = require('mssql');

module.exports = function (app) {
    this.create = async function (params, filename) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);

            const query = `
        INSERT INTO dbo.Formulario (nombre, email, asunto, mensaje)
            VALUES (@Name, @Email, @Subject, @Message);

        `;
            const request = pool.request();
            // Bind values from params object to SQL parameters
            request.input('Name', sql.VarChar, params.Name);
            request.input('Email', sql.VarChar, params.Email);
            request.input('Subject', sql.VarChar, params.Subject);
            request.input('Message', sql.Text, params.Message);

            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.GALLERY/create", err);
        } finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        };
    };
}