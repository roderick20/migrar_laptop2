const log = require('../utils/log.js');
const config = require('../utils/config.js');
const sql = require('mssql');

module.exports = function (app) {
    this.list = async function () {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `
            select * from dbo.Reservations;;
            `;
            result = await pool.request().query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.GALLERY/list", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    },

    this.create = async function (params, filename) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
    
            const query = `
            insert into dbo.Reservations 
            (UniqueId, Name, Phone, CheckIn, CheckOut, Adults, Children, Notes, ProductId)
             Values 
             (@UniqueId, @Name, @Phone, @CheckIn, @CheckOut, @Adults, @Children, @Notes, @ProductId);
            `;
            const request = pool.request();
            // Bind values from params object to SQL parameters
            request.input('UniqueId', sql.NVarChar, params.UniqueId);
            request.input('Name', sql.NVarChar, params.Name);
            request.input('Phone', sql.NVarChar, params.Phone);
            request.input('CheckIn', sql.NVarChar, params.CheckIn);
            request.input('CheckOut', sql.NVarChar, params.CheckOut);
            request.input('Adults', sql.Int, params.Adults);
            request.input('Children', sql.Int, params.Children);
            request.input('Notes', sql.NText, params.Notes);
            request.input('ProductId', sql.Int, params.ProductId);
    
            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.GALLERY/create", err);
        } finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        };
    };

    this.delete = async function (idImagen) {
        let pool;
        let result;
        let error = '';
        try {
            pool = await sql.connect(config.db);
            const query = `
            DELETE FROM Gallery WHERE id = @ID;
            `;
            const request = pool.request();
            request.input('ID', sql.Int, idImagen);
            result = await request.query(query);
        } catch (err) {
            error = err;
            log.logError("dbo.GALLERY/delete", err);
        }
        finally {
            if (pool) {
                pool.close();
            }
        }
        return {
            result,
            error
        }
    }

    //aqui van mas cosas
};