//v1.0.0

const { Console } = require('console');
const crypto = require('crypto');
const fs = require('fs');
const csrf = require('../utils/csrf-prevention');


module.exports = (app) => {
    var userModel = app.models.user;

    app.get('/users', async (req, res, next) => {
        try {
            const { result, error } = await userModel.list();
            res.render('BlogAdmin/users/index', {
                title: 'Lista de usuarios',
                users: result.recordsets[0],
                oficinas: result.recordsets[1],
                error: error
            });
        }
        catch (ex) {
            const error = new Error(ex);
            error.status = 500;
            next(error);
        }
    });

    app.get('/users/create', async (req, res, next) => {
        try {
            res.render('BlogAdmin/users/create', {
                title: 'Agregar usuario',
            });
        }
        catch (ex) {
            const error = new Error(ex);
            error.status = 500;
            next(error);
        }
    });

    app.post('/users/create', async (req, res, next) => {
        try {
            const form ={
                Name: req.body.Nombre,
                Password: req.body.Password,
                Email: req.body.Email,

            }            
            console.log('datos:', form);
                
            await userModel.create(form);
            res.redirect('/users/');
        }
        catch (ex) {
            const error = new Error(ex);
            error.status = 500;
            next(error);
        }
    });

    // app.get('/users/read/:Id', async (req, res) => {
    //     try {
    //         const usuario = await user.select(req.params.Id);
    //         res.render('users/read', {
    //             title: 'Detalle de usuario',
    //             usuario: usuario.result.length > 0 ? usuario.result[0] : null,
    //             error: usuario.error
    //         });
    //     }
    //     catch (ex) {
    //         res.status(500).json({ message: ex });
    //     }
    // });

    app.get('/users/update/:UniqueId', /*csrf.generateCSRFToken,*/ async (req, res, next) => {
        // console.log(req.params.UniqueId);
        const UniqueId = {
            ID: req.params.UniqueId
        };
        console.log('dato: ' + UniqueId);
        const user = await userModel.findById(req.params.UniqueId);
        console.log('datos: ' + user);
    
        try {
            if (user.result && user.result.length > 0) {
                res.render('BlogAdmin/users/update', {
                    title: 'Editar de usuario',
                    /*csrfToken: req.csrf_token,*/
                    csrfToken: 123,
                    user: user.result[0],
                    error: 'No existe'
                });
            } else {
                // Manejar el caso en el que no se encontraron resultados
                res.render('BlogAdmin/users/update', {
                    title: 'Editar de usuario',
                    /*csrfToken: req.csrf_token,*/
                    csrfToken: 123,
                    user: null,
                    error: 'No se encontraron resultados'
                });
            }
        } catch (ex) {
            const error = new Error(ex);
            error.status = 500;
            next(error);
        }
    });
    

    
    
    
    
    
    

    app.post('/users/update', /*csrf.checkCSRFTokenSTP,*/ async (req, res) => {
        try {
            const form = {
                Nombre: req.body.Nombre,
                Email: req.body.Email,
                Enabled: req.body.Estado
            }
            console.log('form:', form);
            await userModel.update(form);
            console.log('ejecutando el update');
            res.redirect('/users/');

            // const user = await user.update(req.body);
            // res.render('users/update', {
            //     title: 'Editar usuario',
            //     user: user.result.recordset[0]
            // });
        }
        catch (ex) {
            res.status(500).json({ message: ex });
        }
    });

    app.get('/users/updatepassword/:id', /*csrf.generateCSRFToken,*/ async (req, res, next) => {
        try {


            res.render('BlogAdmin/users/update_password', {
                title: 'Editar de usuario',
                /*csrfToken: req.csrf_token,*/
                csrfToken: 123,
                UniqueId: req.params.id, //.length > 0 ? usuario.result[0] : null,
                error: ''
            });
        }
        catch (ex) {
            const error = new Error(ex);
            error.status = 500;
            next(error);
        }
    });

    app.post('/users/updatepassword', /*csrf.checkCSRFTokenSTP,*/ async (req, res) => {
        try {
            console.log('/users/updatepassword');
            await userModel.updatePassword(req.body);
            res.redirect('/users/');

            // const user = await user.update(req.body);
            // res.render('users/update', {
            //     title: 'Editar usuario',
            //     user: user.result.recordset[0]
            // });
        }
        catch (ex) {
            res.status(500).json({ message: ex });
        }
    });

    app.get('/users/delete/:id', async (req, res) => {
        try {
            res.render('BlogAdmin/users/delete', {
                title: 'Eliminar usuario',
                UniqueId: req.params.id,
            });
        }
        catch (ex) {
            res.status(500).json({ message: ex });
        }
    });

    app.post('/users/delete', async (req, res) => {
        try {
             const borrar ={
                UniqueId: req.body.UniqueId,
             }
            console.log('dato: ' + borrar);
            const usuario = await userModel.remove(borrar);
            res.redirect('/users/');
        } catch (ex) {
            res.status(500).json({ message: ex });
        }
    });

    app.get('/users/addAlmacen/:id', async (req, res, next) => {
        const { result, error } = await oficinaModel.findAll();
        console.log(result.recordset);
        try {            
            res.render('BlogAdmin/users/addAlmacen', {
                title: 'Agregar almacén',
                UserId: req.params.id,
                oficinas: result.recordset
            });
        }
        catch (ex) {
            const error = new Error(ex);
            error.status = 500;
            next(error);
        }
    });

    app.post('/users/addAlmacen', async (req, res, next) => {
        try {
            const { result, error } = await userModel.addAlmacen(req.body);
            res.redirect('/users/');
        }
        catch (ex) {
            const error = new Error(ex);
            error.status = 500;
            next(error);
        }
    });

    app.get('/users/deleteAlmacen/:UsuarioID/:OficinaAlmacenID', async (req, res, next) => {
        try {
            const { result, error } = await userModel.deleteAlmacen(req.params.UsuarioID, req.params.OficinaAlmacenID);
            res.redirect('/users/');
        }
        catch (ex) {
            const error = new Error(ex);
            error.status = 500;
            next(error);
        }
    });

    


}
