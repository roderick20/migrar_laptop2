module.exports = (app) => {
    var Post = require('../models/Post.js');
    //var user = app.models.user;
    app.get('/Blog', async (req, res) => {
        try {
            const posts = await Post.listposts();
            res.render('BlogUser/Blog', {
                title: 'Blog',
                layout: './shared/layout_home.ejs',
                posts : posts.result.recordset,
            });
        } catch (ex) {
            res.render('index/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });
}
