const express = require('express');
const app = express();

// Configurar middleware para analizar datos de formularios
app.use(express.urlencoded({ extended: true }));
module.exports = (app) => {

    const Configuracion = require("../models/Configuracion.js");
    //Vista principal de configuracion
    app.get('/Configuracion', async (req, res) => {
        try {
            const { result, error } = await Configuracion.list();
            //console.log(result.recordset);
            res.render('BlogAdmin/Configuracion/index', {
                title: 'Configuracion',
                config: result.recordset
            });
        } catch (ex) {
            res.render('BlogAdmin/Configuracion/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });

    //configuracion EDIT
    app.get('/Configuracion/EditConfiguracion?:UniqueId', async (req, res) => {
        console.log("Entramos en el controlador");
        try {
            const { result, error } = await Configuracion.listById(req.query.UniqueId);
            console.log("Estamos en el controlador");
            console.log(result.recordset);
            res.render('BlogAdmin/Configuracion/Edit/EditConfiguracion', {
                title: 'Editar Configuracion',
                Datos: result.recordset[0]
            });
        } catch (ex) {
            res.render('BlogAdmin/Configuracion/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });

    app.post('/Configuracion/EditConfiguracionAction',async(req, res, next)=>{
        try {
            const params = req.body
            // console.log(params);
            await Configuracion.update(params);
            res.redirect('/Configuracion');
        } catch (ex) {
            const error = new Error(ex);
            error.status = 500;
            next(error);
        }
    })


    //Imagenes EDIT
    app.get('/Configuracion/EditImagenes', async (req, res) => {
        try {
            const { result, error } = await Configuracion.list();
            console.log(result.recordset);
            res.render('BlogAdmin/Configuracion/index', {
                title: 'Configuracion',
                config: result.recordset
            });
        } catch (ex) {
            res.render('BlogAdmin/Configuracion/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });
    //Estilos EDIT
    app.get('/Configuracion/EditEstilos?:UniqueId', async (req, res) => {
        console.log("Entramos en el controlador");
        try {
            const { result, error } = await Configuracion.listById(req.query.UniqueId);
            console.log("Estamos en el controlador");
            console.log(result.recordset);
            res.render('BlogAdmin/Configuracion/Edit/EditEstilos', {
                title: 'Editar Configuracion',
                Datos: result.recordset[0]
            });
        } catch (ex) {
            res.render('BlogAdmin/Configuracion/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });

    app.post('/Configuracion/EditEstilosAction',async(req, res, next)=>{
        try {
            const params = req.body
            await Configuracion.update(params);
            res.redirect('/Configuracion');
        } catch (ex) {
            const error = new Error(ex);
            error.status = 500;
            next(error);
        }
    })
}
