module.exports = (app) => {



    var Contacto = require('../models/Contacto.js');

    app.post('/Contactaction', async (req, res) => {
        try {
            // Access form data from req.body using the correct property names
            const form = {
                Name: req.body.Name,
                Email: req.body.Email,
                Subject: req.body.Subject,
                Message: req.body.Message,
            };

            console.log('datos:', form);

            // Call the create function with the form data
            const result = await Contacto.create(form);
            "use strict";
            const nodemailer = require("nodemailer");

            const transportOptions = {
                host: '158.69.104.108',
                port: '587',
                auth: { user: 'informes@innovaarequipa.pe', pass: 'informes?23' },
                secureConnection: true,
                tls: {
                    secure: false,
                    ignoreTLS: true,
                    rejectUnauthorized: false
                }
            };

            const transporter = nodemailer.createTransport(transportOptions);
            const mailOptions = {
                from: 'reservas@majestadhotel.com',
                to: req.body.Email,
                subject: 'Confirmación de Recepción de sus Datos en Majestad Boutique Hotel',
                html: `
                <html>
                    <head>
                        <style>
                            body {
                                font-family: Arial, sans-serif;
                            }
                            .container {
                                max-width: 600px;
                                margin: 0 auto;
                                padding: 20px;
                                text-align: center;
                                background-color: #f5f5f5;
                            }
                            .header {
                                background-color: #333;
                                color: #fff;
                                padding: 10px;
                            }
                            .header h1 {
                                font-size: 24px;
                            }
                            .content {
                                padding: 20px;
                                background-color: #fff;
                            }
                        </style>
                    </head>
                    <body>
                        <div class="container">
                            <div class="header">
                                <h1>Hotel Majestad Boutique</h1>
                            </div>
                            <div class="content">
                                <h2>¡Confirmación de Recepción de sus Datos!</h2>
                                <p>Estimado ${req.body.Name},</p>
                                <p>Le informamos que hemos recibido correctamente sus datos para su estadía en el Hotel Majestad Boutique.</p>
                                <p>Nos pondremos en contacto con usted lo antes posible</p>
                                <p>Detalles que hemos recibido:</p>
                                <ul>
                                    <li>Correo: ${req.body.Email}</li>
                                    <li>Asunto: ${req.body.Subject}</li>
                                    <li>Mensaje: ${req.body.Message}</li>
                                </ul>
                                <p>Gracias por elegir el Hotel Majestad Astorga.</p>
                            </div>
                        </div>
                    </body>
                </html>
            `
            };

            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    console.log('Error al enviar el correo:', error);
                } else {
                    console.log('El correo se ha enviado con éxito');
                }
            });


            res.redirect('/donecontacto'); // Assuming this is the correct redirection path


        } catch (ex) {
            res.render('BlogUser/error', {
                title: 'Lista de tablas',
                error: ex
            });
        }
    });
    app.get('/donecontacto', async (req, res) => {
        try {
            res.render('BlogUser/ReservaHecha.ejs', {
                title: 'Reserva Hecha',
                layout: './shared/layout_home.ejs',
            });
        } catch (ex) {
            res.render('BlogUser/index', {
                title: 'Inicio',
                error: ex
            });
        }
    });
}