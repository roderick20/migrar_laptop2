const { Console } = require('console');
const crypto = require('crypto');
const fs = require('fs');
const multer = require('multer');
const uuid = require('uuid');

module.exports = (app) => {

    var Post = require('../models/Post.js');
    var Tours = require('../models/Tours.js');

    app.get('/Post', async (req, res) => {
        try {
            const productos = await Tours.list();
            //console.log('datos '+ result);
            res.render('BlogAdmin/BlogPosts/index', {
                title: 'Productos',
                productos: productos.result.recordset,
            });
        } catch (ex) {
            res.render('index/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });

    app.get('/post/createform', async (req, res) => {
        try {
            res.render('BlogAdmin/BlogPosts/create', {
                title: 'Crear un mensaje',
            });
        } catch (ex) {
            res.render('BlogAdmin/BlogPosts/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });

    app.post('/post/createaction', async (req, res) => {
        try {
            console.log("Estos son los datos recogidos");
            console.log(req.body);
            await Post.create(req.body);
            res.redirect('/post')
        } catch (ex) {
            res.render('BlogAdmin/post/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });

    app.get('/post/show?:UniqueId', async (req, res) => {
        console.log("Entramos en el controlador: " + req.query.UniqueId);
        try {
            const UniqueId2 = req.query.UniqueId;
            const DateUpdate = await Post.listBySlug(UniqueId2);
            console.log("Estos son los datos recibidos " + JSON.stringify(DateUpdate.result.recordset[0]));
            res.render('BlogUser/Productos/index.ejs', {
                title: 'Editar Configuracion',
                Datos: DateUpdate.result.recordset[0],
                layout: './shared/layout_home.ejs'
            });
        } catch (ex) {
            res.render('BlogAdmin/Productos/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });


    // Solucionar errores
    app.get('/post/Update?:UniqueId', async (req, res) => {
        try {
            const UniqueId2 = req.query.UniqueId;
            const DateUpdate = await Post.listBySlug(UniqueId2);
            //console.log("Estos son los datos recibidos " + JSON.stringify(DateUpdate.result.recordset[0]));
            res.render('BlogAdmin/BlogPosts/Update', {
                title: 'Crear un mensaje',
                BlogPost: DateUpdate.result.recordset[0]
            });
        } catch (ex) {
            res.render('BlogAdmin/BlogPosts/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });
    app.post('/post/updateaction', async (req, res) => {
        try {
            console.log("Estos son los datos recogidos");
            console.log(req.body);
            // Extraer los valores necesarios de req.body
            const {
                UniqueId,
                CategoryId,
                Title,
                file,
                Body,
                Summary,
                Tags,
                Price,
                IsPublish,
                ImagenOriginal,
            } = req.body;
    
            // Llamar a la función de actualización con los valores extraídos
            await Post.listUpdate(
                UniqueId,
                CategoryId,
                Title,
                file,
                Body,
                Summary,
                Tags,
                Price,
                IsPublish,
                ImagenOriginal,
            );
    
            res.redirect('/post');
        } catch (ex) {
            res.render('BlogAdmin/post/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });

    //controlador del delete
    app.get('/eliminarBlogPost', async (req, res) => {
        try {
            const UniqueId2 = req.query.UniqueId;
            console.log('Eliminar');
            console.log(req.query.UniqueId);
            await Post.delete(UniqueId2);
            res.redirect('/post');
        } catch (ex) {
            const error = new Error(ex);
            error.status = 500;
            next(error);
        }
    });

}