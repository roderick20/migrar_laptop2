const modelLogin = require('../models/login');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;

module.exports = (app) => {
    var Post = require('../models/Post.js');



    app.get('/login', async (req, res) => {
        res.render('BlogAdmin/home/login', {
            title: 'Inicio',
            layout: './shared/layout_login.ejs',
            error: ''
        });
    });
    passport.use(new LocalStrategy(
        async (username, password, done) => {
            let login = await modelLogin.login(username, password);

            if (login.result && login.result.recordsets[0].length > 0) {
                user = login.result.recordset[0];
                return done(null, user);
            }
            else {
                return done(null, false, { message: 'Credenciales inválidas' });
            }
        }
    ));

    passport.serializeUser((user, done) => {
        const userSessionData = { 
            id: user.Id, 
            email: user.Email, 
            name: user.Name };
        done(null, userSessionData); // Serializa el usuario por su dirección de correo electrónico
    });

    passport.deserializeUser((user, done) => {
        // Reemplaza esto con tu propia lógica para buscar al usuario en la base de datos por su dirección de correo electrónico
        done(null, { user });
    });

    app.post('/login', passport.authenticate('local', {
        successRedirect: '/main', // Redirige a '/main' en caso de éxito
        failureRedirect: '/login', // Redirige a '/login' en caso de falla
        failureFlash: true // Activa el uso de flash messages para mostrar un mensaje de error
    }));
    app.get('/logout', (req, res) => {
        //req.session.destroy();

        req.session.isLoggedIn = false;
        req.session.useName = null;
        req.session.userId = null;
        req.session.level = null;


        res.redirect('/');
    });
    //var user = app.models.user;
    app.get('/', async (req, res) => {
        try {
            const productos = await Post.listhabitaciones();
            //console.log('datos '+ result);
            res.render('BlogUser/index', {
                title: 'Inicio',
                layout: './shared/layout_home.ejs',
                productos: productos.result.recordset,
            });
        } catch (ex) {
            res.render('index/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });
    app.get('/index', async (req, res) => {
        try {
            const productos = await Post.listproductos();
            const posts = await Post.listposts();
            const { result, error } = await Post.listservicios();
            //console.log('datos '+ result);
            res.render('BlogUser/index', {
                title: 'Inicio',
                layout: './shared/layout_home.ejs',
                Servicios: result.recordset,
                productos: productos.result.recordset,
                posts: posts.result.recordset,
            });
        } catch (ex) {
            res.render('index/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });
    app.get('/main', async (req, res) => {
        res.render('BlogAdmin/dashboard', {
            title: 'Dashboard',
            error: ''
        });
    });

    // app.get('/', async (req, res) => {
    //     res.render('home/login', {
    //         title: 'Inicio',
    //         layout: './shared/layout_login.ejs',
    //         error: ''
    //     });
    // });
    app.post('/admin', async (req, res) => {
        res.render('blogAdmin/dashboard', {
            title: 'Dashboard',
            layout: './shared/layout.ejs',

        });
    });
    app.get('/Servicios', async (req, res) => {

        res.render('BlogUser/Servicios', {
            title: 'Servicios',
            layout: './shared/layout_home.ejs',
        });
    });
    app.get('/Nosotros', async (req, res) => {

        res.render('BlogUser/Nosotros', {
            title: 'Nosotros',
            layout: './shared/layout_home.ejs',
        });
    });
    app.get('/Productos', async (req, res) => {

        res.render('BlogUser/Productos', {
            title: 'Nosotros',
            layout: './shared/layout_home.ejs',
        });
    });
    app.get('/Blog', async (req, res) => {

        res.render('BlogUser/Blog', {
            title: 'Blog',
            layout: './shared/layout_home.ejs',
        });
    });
    app.get('/contact', async (req, res) => {

        res.render('BlogUser/Contacto', {
            title: 'Blog',
            layout: './shared/layout_home.ejs',
        });
    });
    app.get('/Fotos', async (req, res) => {

        res.render('BlogUser/Gallery', {
            title: 'Fotos',
            layout: './shared/layout_home.ejs',
        });
    });
}