const crypto = require('crypto');
const fs = require('fs');
const multer = require('multer');
const uuid = require('uuid');
const nodemailer = require("nodemailer");


const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, uuid.v4() + "-" + file.originalname);
    }
});

const upload = multer({ storage: storage });
module.exports = (app) => {

    var Post = require('../models/Post.js');
    var Habitaciones = require('../models/Habitaciones.js');

    app.get('/Rooms', async (req, res) => {
        try {
            const productos = await Post.listhabitaciones();
            // console.log(tablagaleria.result.recordset);
            res.render('BlogUser/Rooms', {
                title: 'Cuartos',
                layout: './shared/layout_home.ejs',
                productos: productos.result.recordset
            });
        } catch (ex) {
            res.render('BlogAdmin/Galleries/index', {
                title: 'Lista de tablas',
                error: ex
            });
        }
    });
    app.get('/Reserve', async (req, res) => {
        try {
            const productos = await Post.listproductos();
            // console.log(tablagaleria.result.recordset);
            res.render('BlogUser/Reserve', {
                title: 'Cuartos',
                layout: './shared/layout_home.ejs',
                productos: productos.result.recordset
            });
        } catch (ex) {
            res.render('BlogAdmin/Galleries/index', {
                title: 'Lista de tablas',
                error: ex
            });
        }
    });

    app.get('/availability', async (req, res) => {
        try {
            // Extract data from the request body
            const form = req.body;


            const productos = await Post.listhabitaciones();

            // Render the second form
            res.render('BlogUser/Reserve', {
                title: 'Cuartos',
                layout: './shared/layout_home.ejs',
                form: form,
                productos: productos.result.recordset,
            });
        } catch (ex) {
            res.render('BlogAdmin/Galleries/index', {
                title: 'Lista de tablas',
                error: ex,
            });
        }
    });

    app.post('/availability', async (req, res) => {
        try {
            // Extract data from the request body
            const form = req.body;
            console.log(req.body);
            const productos = await Post.listproductos();

            // Render the second form
            res.render('BlogUser/Reserve', {
                title: 'Cuartos',
                layout: './shared/layout_home.ejs',
                form: form,
                productos: productos.result.recordset,
            });
        } catch (ex) {
            res.render('BlogAdmin/Galleries/index', {
                title: 'Lista de tablas',
                error: ex,
            });
        }
    });
    app.get('/reservations', async (req, res) => {
        try {
            const form = req.query;
            console.log(form);
            const productos = await Post.listproductos();
            // console.log(tablagaleria.result.recordset);
            res.render('BlogUser/Reservations', {
                title: 'Cuartos',
                layout: './shared/layout_home.ejs',
                form: form,
                productos: productos.result.recordset
            });
        } catch (ex) {
            res.render('BlogAdmin/Galleries/index', {
                title: 'Lista de tablas',
                error: ex
            });
        }
    });
    app.post('/reservationsaction', async (req, res) => {
        try {
            // Access form data from req.body using the correct property names
            const form = {
                UniqueId: req.body.UniqueId,
                Name: req.body.Name,
                Phone: req.body.Phone,
                Email: req.body.Email,
                CheckIn: formatDateForSQL(req.body.CheckIn),
                CheckOut: formatDateForSQL(req.body.CheckOut),
                Adults: req.body.Adults,
                Children: req.body.Children,
                Notes: req.body.Notes,
                ProductId: req.body.ProductId
            };

            function formatDateForSQL(dateString) {
                const parts = dateString.split('/');
                if (parts.length === 3) {
                    const [day, month, year] = parts;
                    // Convert the date to 'YYYY-MM-DD' format
                    return `${year}-${month}-${day} 00:00:00.000`;
                }
                // If the date format is incorrect, return an empty string or handle the error as needed.
                return '';
            }

            console.log('datos:', form);

            // Call the create function with the form data
            const result = await Habitaciones.create(form);
            "use strict";
            const nodemailer = require("nodemailer");

            const transportOptions = {
                host: '158.69.104.108',
                port: '587',
                auth: { user: 'informes@innovaarequipa.pe', pass: 'informes?23' },
                secureConnection: true,
                tls: {
                    secure: false,
                    ignoreTLS: true,
                    rejectUnauthorized: false
                }
            };

            const transporter = nodemailer.createTransport(transportOptions);
            const mailOptions = {
                from: 'MajestadBoutiqueHotel@gmail.com',
                to: req.body.Email,
                subject: 'Confirmación de Reserva en Hotel Majestad Boutique',
                // text: `<h3>Confirmación de Reserva en Hotel Majestad Boutique</h3>
                // <p>Gracias por reservar su estadía en el Hotel Majestad Boutique. Hemos recibido su reserva y la hemos confirmado.</a></p>
                // <p>Saludos</p>`,
                html: `
                    <html>
                        <head>
                            <style>
                                body {
                                    font-family: Arial, sans-serif;
                                }
                                .container {
                                    max-width: 600px;
                                    margin: 0 auto;
                                    padding: 20px;
                                    text-align: center;
                                    background-color: #f5f5f5;
                                }
                                .header {
                                    background-color: #333;
                                    color: #fff;
                                    padding: 10px;
                                }
                                .header h1 {
                                    font-size: 24px;
                                }
                                .content {
                                    padding: 20px;
                                    background-color: #fff;
                                }
                            </style>
                        </head>
                        <body>
                            <div class="container">
                                <div class="header">
                                    <h1>Hotel Majestad Boutique</h1>
                                </div>
                                <div class="content">
                                    <h2>¡Confirmación de Reserva!</h2>
                                    <p>Estimado ${req.body.Name},</p>
                                    <p>Gracias por reservar su estadía en el Hotel Majestad Boutique. Hemos recibido su reserva y la hemos confirmado.</p>
                                    <p>Detalles de la Reserva:</p>
                                    <ul>
                                        <li>Fecha de Check-In: ${req.body.CheckIn}</li>
                                        <li>Fecha de Check-Out: ${req.body.CheckOut}</li>
                                        <li>Adultos: ${req.body.Adults}</li>
                                        <li>Niños: ${req.body.Children}</li>
                                        <li>Notas: ${req.body.Notes}</li>
                                    </ul>
                                    <p>Esperamos que tenga una estancia agradable en nuestro hotel. Si necesita realizar cambios en su reserva o tiene alguna pregunta, no dude en ponerse en contacto con nosotros.</p>
                                    <p>Gracias por elegir el Hotel Majestad Boutique.</p>
                                </div>
                            </div>
                        </body>
                    </html>
                `
            };

            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    console.log('Error al enviar el correo:', error);
                } else {
                    console.log('El correo se ha enviado con éxito');
                }
            });


            res.redirect('/done'); // Assuming this is the correct redirection path


        } catch (ex) {
            res.render('BlogUser/error', {
                title: 'Lista de tablas',
                error: ex
            });
        }
    });

    app.get('/done', async (req, res) => {
        try {
            res.render('BlogUser/ReservaHecha.ejs', {
                title: 'Reserva Hecha',
                layout: './shared/layout_home.ejs',
            });
        } catch (ex) {
            res.render('BlogUser/index', {
                title: 'Inicio',
                error: ex
            });
        }
    });
    app.get('/eliminarreservacion/:UniqueId', async (req, res) => {
        try {
            console.log('llego el id');
            console.log(req.params.UniqueId);
            const UniqueId2 = req.params.UniqueId;
            console.log('Eliminar');
            console.log(req.query.UniqueId);
            await Post.deletereservacion(UniqueId2);
            res.redirect('/reservaciones');
        } catch (ex) {
            const error = new Error(ex);
            error.status = 500;
            next(error);
        }
    });



};

