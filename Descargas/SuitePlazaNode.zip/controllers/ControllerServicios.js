

module.exports = (app) => {
    var Post = require('../models/Post.js');
    //var user = app.models.user;
    app.get('/Services', async (req, res) => {
        try {
            const { result, error } = await Post.listservicios();
            res.render('BlogUser/servicios', {
                title: 'Desarrollo de software',
                layout: './shared/layout_home.ejs',
                Servicios: result.recordset,
            });
        } catch (ex) {
            res.render('index/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });
}
