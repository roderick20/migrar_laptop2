const express = require('express');
const app = express();

// Configurar middleware para analizar datos de formularios
app.use(express.urlencoded({ extended: true }));
module.exports = (app) => {

    // var mensaje = app.models.Mensajes;
    const Mensajes = require("../models/Mensajes");

    app.get('/reservaciones', async (req, res) => {
        try {
            const { result, error } = await Mensajes.list();
            res.render('BlogAdmin/mensajes/index', {
                title: 'Reservaciones',
                mnsj: result.recordset
            });
        } catch (ex) {
            res.render('BlogAdmin/mensajes/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });

    // Dentro de tu enrutador de Express.js
    app.get('/mensajes/detalles/:Id', async (req, res) => {
        console.log('llego el id ' + req.params.Id );
        const Id = req.params.Id;
        try {
            const { result, error } = await Mensajes.listmensaje(Id);
            res.render('BlogAdmin/mensajes/details', {
                title: 'Detalles del Mensaje',
                mnsjid: result.recordset[0]
            });
        } catch (ex) {
            res.render('BlogAdmin/mensajes/error', {
                title: 'Error al obtener detalles del mensaje',
                error: ex
            });
        }
    });

    app.get('/mensajes/createform', async (req, res) => {
        try {
            res.render('BlogAdmin/mensajes/create', {
                title: 'Crear un mensaje',
            });
        } catch (ex) {
            res.render('BlogAdmin/mensajes/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });

    app.post('/mensajes/createaction', async (req, res) => {
        try {
            const Id = parseInt(req.body.Id);
            //await Mensajes.create(req.body,Id);
            console.log('estos son los datos que estoy recibiendo ' + Id),
            res.redirect('/mensajes')
        } catch (ex) {
            res.render('mensajes/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });
}
