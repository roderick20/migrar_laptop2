const crypto = require('crypto');
const fs = require('fs');
const multer = require('multer');
const uuid = require('uuid');

module.exports = (app) => {

    var Tours = require('../models/Tours.js');

    app.get('/Tours', async (req, res) => {
        try {
            const { result, error } = await Tours.list();
            res.render('BlogUser/Tours.ejs', {
                title: 'Tours',
                layout: './shared/layout_home.ejs',
                Tour: result.recordset
            });
        } catch (ex) {
            res.render('Tours/error', {
                title: 'Lista de Error',
                error: ex
            });
        }
    });
}