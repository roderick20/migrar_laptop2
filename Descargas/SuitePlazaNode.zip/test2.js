const crypto = require('crypto');

function encryptText(text, key, iv) {
    const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
}

// Ejemplo de uso
const plaintext = 'Hola, mundo!';
const encryptionKey = '0123456789abcdef0123456789abcdef'; // 32 bytes para AES-256
const iv = 'abcdef0123456789'; // 16 bytes para AES

const encryptedText = encryptText(plaintext, encryptionKey, iv);
console.log('Texto encriptado:', encryptedText);