<?php

declare(strict_types=1);

namespace Greenter\Ws\Builder;

use LogicException;

class DocumentNoSupportException extends LogicException
{

}