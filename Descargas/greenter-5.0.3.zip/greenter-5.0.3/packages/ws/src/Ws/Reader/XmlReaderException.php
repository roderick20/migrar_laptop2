<?php

declare(strict_types=1);

namespace Greenter\Ws\Reader;

use LogicException;

class XmlReaderException extends LogicException
{

}