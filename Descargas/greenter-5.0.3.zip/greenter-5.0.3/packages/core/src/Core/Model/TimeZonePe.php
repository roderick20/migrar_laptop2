<?php

declare(strict_types=1);

namespace Greenter\Model;

final class TimeZonePe
{
    /*
     * Default Timezone Peru
     */
    public const DEFAULT = 'America/Lima';
}