<?php
/**
 * Created by PhpStorm.
 * User: Giansalex
 * Date: 09/10/2017
 * Time: 23:00.
 */

declare(strict_types=1);

namespace Greenter\Validator\Loader;

class ReversionLoader extends VoidedLoader
{
}
