const express = require('express');
const app = express();

const cookieParser = require('cookie-parser');
const expressLayouts = require('express-ejs-layouts')
const expressSession = require('express-session');
const bp = require('body-parser');
const consign = require('consign');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const flash = require('connect-flash');
require('dotenv').config();

app.set('views', 'views');
app.set('view engine', 'ejs');
app.set('layout', './shared/layout');

app.use(expressLayouts);
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));

app.use(bp.urlencoded({ extended: true }))
app.use(cookieParser("cookie-parser-secret"));
app.use(express.json());
app.use(expressSession({ secret: 'thisismysecrctekeyfhrgfgrfrty84fwir767', resave: true, saveUninitialized: true }));
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());
	
const moment = require('moment');

app.use((req, res, next) => {
	res.locals.moment = moment;	
	res.locals.messages = req.flash();
	next();
});

app.use((req, res, next) => {
	res.locals.username = "";
	res.locals.userId = "";
	res.locals.role = "";
	res.locals.firstname = "";
	let urlAnonymous = ['/logout', '/login', '/register', '/confirmaremail', '/recoverypassword'];
	if (req.originalUrl != '/') {
		const urlFound = urlAnonymous.find(item => req.originalUrl.startsWith(item) && item != '/');
		
		if (urlFound == undefined) {
			if (req.isAuthenticated()) {      
				res.locals.name = req.session.passport.user.name; 
				res.locals.lastname = req.session.passport.user.lastname; 
				res.locals.userid = req.session.passport.user.id; 
				
				return next();
			} else {
				res.redirect('/login');
				return;
			}
		}
	} else {
		if (req.isAuthenticated()) {
			
				res.locals.username = req.session.passport.user.user.name; // Aquí corregí 'req.session.req.session' a 'req.session.passport'
				res.locals.userid = req.session.passport.user.id; // Corregí 'req.session.userId' a 'req.session.passport.user.id'
			
		} else {
			res.redirect('/login');
			return;
		}
	}

	next();
});

const oneDay = 1000 * 60 * 60 * 24;

consign()
		.include('models')
		.then('controllers')
		.into(app);

const port = process.env.PORT || 3000;

app.listen(port, () => {
	console.log('Aplicación iniciada en el puerto 3000');
});	