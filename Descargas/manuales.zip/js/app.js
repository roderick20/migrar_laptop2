// document.addEventListener("DOMContentLoaded", (() => {
// if (document.getElementsByClassName("js-simplebar")[0]) {        
// const e = document.getElementsByClassName("sidebar")[0];
// document.getElementsByClassName("sidebar-toggle")[0].addEventListener("click", (() => {
// e.classList.toggle("collapsed"),
// e.addEventListener("transitionend", (() => { window.dispatchEvent(new Event("resize")) }))
// }))
// }
// }));

document.addEventListener("DOMContentLoaded", (() => {

    $('.footer').load('footer.html');

    $('#sidebar').load('menu.html', function () {
        if (document.getElementsByClassName("js-simplebar")[0]) {
            const e = document.getElementsByClassName("sidebar")[0];
            document.getElementsByClassName("sidebar-toggle")[0].addEventListener("click", (() => {
                e.classList.toggle("collapsed"),
                    e.addEventListener("transitionend", (() => { window.dispatchEvent(new Event("resize")) }))
            }))
        }
    });

}));